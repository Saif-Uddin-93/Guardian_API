import boto3, json
from botocore.exceptions import ClientError, BotoCoreError

region_name = "eu-west-2"

iam_client = boto3.client('iam', region_name=region_name)   

def create_iam_role(client=iam_client):
    """
    Create an IAM role with the specified client.

    Parameters:
        client (boto3.client): The IAM client to use for creating the role.

    Returns:
        tuple: The Role ID and Role ARN of the created IAM role.
    """
    role_name = 'guardian-iam-role'

    # policies = [
    #     'arn:aws:iam::aws:policy/AWSLambda_FullAccess',
    #     'arn:aws:iam::aws:policy/AmazonAPIGatewayAdministrator',
    #     'arn:aws:iam::aws:policy/AmazonSQSFullAccess'
    # ]

    trust_policy_doc = json.dumps({
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {
                    "Service": [
                        "lambda.amazonaws.com"
                    ]
                },
                "Action": "sts:AssumeRole"
            }
        ]
    })

    try:
        role_response = client.create_role(
            RoleName=role_name,
            AssumeRolePolicyDocument=trust_policy_doc
        )

        permissions_policy_doc = json.dumps({
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": [
                        "lambda:*",
                        "sqs:*",
                        "apigateway:*"
                    ],
                    "Resource": "*"
                }
            ]
        })

        # Create and attach the permissions policy
        policy_response = client.create_policy(
            PolicyName=f'{role_name}-policy',
            PolicyDocument=permissions_policy_doc
        )

        policy_arn = policy_response['Policy']['Arn']

        client.attach_role_policy(
            RoleName=role_name,
            PolicyArn=policy_arn
        )

        role_arn = role_response['Role']['Arn']
        role_id = client.get_role(RoleName=role_name)['Role']['RoleId']

        return role_id, role_arn

    except ClientError as e:
        print(f"ClientError: {e.response['Error']['Message']}")
        return None, None

    except BotoCoreError as e:
        print(f"BotoCoreError: {str(e)}")
        return None, None

    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return None, None

# sqs client
sqs_client = boto3.client('sqs', region_name=region_name)

def create_sqs_queue(queue_name: str, client=sqs_client):
    """
    Create an SQS queue with the specified name.

    Parameters:
        queue_name (str): The name of the queue to create.
        client (boto3.client): The SQS client to use for creating the queue.

    Returns:
        dict: The response from the create_queue call.
    """
    return client.create_queue(
        QueueName=f"{queue_name}.fifo",
        Attributes={
            'DelaySeconds': '0',
            'MessageRetentionPeriod': '259200'  # 3 days
        }
    )


def send_message_to_sqs(url: str, message: str, client=sqs_client):
    """
    Send a message to the specified SQS queue.

    Parameters:
        url (str): The URL of the SQS queue.
        message (str): The message to send.
        client (boto3.client): The SQS client to use for sending the message.

    Returns:
        str: The MessageId of the sent message if successful, None otherwise.
    """
    if message == "":
        error_response = {
                'Error': {
                    'Code': 'message',
                    'Message': 'Message cannot be empty',
                }
            }
        raise ClientError(error_response, "empty_message")
    try:
        response = client.send_message(
            QueueUrl=url,
            MessageBody=message
        )

        # Check if the message was successfully sent
        if "MessageId" in response:
            print(f"Message sent successfully! MessageId: {response['MessageId']}")
            return response['MessageId']
        else:
            print("Message sending failed: No MessageId returned")
            return None

    except ClientError as e:
        # Handle AWS Client Errors
        print(f"ClientError: {e.response['Error']['Message']}")
        return None

    except BotoCoreError as e:
        # Handle boto3-related errors
        print(f"BotoCoreError: {str(e)}")
        return None

    except Exception as e:
        # Catch any other unexpected exceptions
        print(f"Unexpected error: {str(e)}")
        return None


def receive_messages_from_sqs(url: str, client=sqs_client, max_messages=10) -> list:
    """
    Receive messages from the specified SQS queue.

    Parameters:
        url (str): The URL of the SQS queue.
        client (boto3.client): The SQS client to use for receiving messages.
        max_messages (int): The maximum number of messages to receive (default is 10).

    Returns:
        list: A list of messages received from the queue.
    """
    if max_messages > 10:
        max_messages = 10
    response = client.receive_message(
        QueueUrl=url,
        MaxNumberOfMessages=max_messages,
        # WaitTimeSeconds=5  # Wait time to ensure messages are available
    )
    if "Messages" in response:
        return response["Messages"]
    else:
        return []


# apigateway client v1
api_client = boto3.client('apigateway', region_name=region_name)

def create_api(api_name='guardian-api'):
    apigw_client(api_name=api_name)

def apigw_client(integration_type='HTTP', api_name='guardian-api'):

    api_id = None
    response = None

    def api_exists(name):
        response = api_client.get_rest_apis()
        for item in response['items']:
            if item['name'] == name:
                return True
        return False
    
    if not api_exists(api_name):

        response = api_client.create_rest_api(
            name = api_name,
            description = 'REST API to retrieve guardian data',
            endpointConfiguration = {
                'types': ['REGIONAL']
            }
        )
        api_id = response['id']

        resources = api_client.get_resources(restApiId=api_id)
        root_id = resources['items'][0]['id']

        api_client.create_usage_plan(
            name='Daily',
            description='50 api calls per day',
            quota={
                'limit': 50,
                'period': 'DAY'
            }
        )

        api_client.put_method(
            restApiId=api_id,
            resourceId=root_id,
            httpMethod='GET',
            authorizationType='NONE',
            requestParameters={
                'method.request.querystring.query': True,
                'method.request.querystring.queue-name': True,
                'method.request.querystring.from-date': False,
                'method.request.querystring.page-size': False,
                'method.request.querystring.star-rating': False,
            }
        )

        mapping_template = """
#set($allParams = $input.params())
{
  "status" : "200",
  "body-json" : $input.json('$'),
  "params" : {
    #foreach($type in $allParams.keySet())
      #set($params = $allParams.get($type))
      "$type" : {
        #foreach($paramName in $params.keySet())
          "$paramName" : "$util.escapeJavaScript($params.get($paramName))"
          #if($foreach.hasNext),#end
        #end
      }
      #if($foreach.hasNext),#end
    #end
  },
  "stage-variables" : {
    #foreach($key in $stageVariables.keySet())
      "$key" : "$util.escapeJavaScript($stageVariables.get($key))"
      #if($foreach.hasNext),#end
    #end
  },
  "context" : {
    "account-id" : "$context.identity.accountId",
    "api-id" : "$context.apiId",
    "api-key" : "$context.identity.apiKey",
    "authorizer-principal-id" : "$context.authorizer.principalId",
    "caller" : "$context.identity.caller",
    "cognito-authentication-provider" : "$context.identity.cognitoAuthenticationProvider",
    "cognito-authentication-type" : "$context.identity.cognitoAuthenticationType",
    "cognito-identity-id" : "$context.identity.cognitoIdentityId",
    "cognito-identity-pool-id" : "$context.identity.cognitoIdentityPoolId",
    "http-method" : "$context.httpMethod",
    "stage" : "$context.stage",
    "source-ip" : "$context.identity.sourceIp",
    "user" : "$context.identity.user",
    "user-agent" : "$context.identity.userAgent",
    "user-arn" : "$context.identity.userArn",
    "request-id" : "$context.requestId",
    "resource-id" : "$context.resourceId",
    "resource-path" : "$context.resourcePath"
  }
}
"""
        
        api_client.put_integration(
            restApiId=api_id,
            resourceId=root_id,
            httpMethod='GET',
            type=integration_type,
            requestTemplates={
                'application/json': mapping_template
            }
        )
    else:
        for item in response['items']:
            if item['name'] == api_name:
                api_id = item['id']

    api_client.create_deployment(restApiId=api_id, stageName='dev')

    return api_client, api_id


# lambda client
lambda_client = boto3.client('lambda', region_name=region_name)

def create_lambda(role_id:str, role_arn:str, client = lambda_client):
    # Create functions
    with open('sqs_send.zip', 'rb') as f:
        sqs_send_code = f.read()

    with open('sqs_receive.zip', 'rb') as f:
        sqs_receive_code = f.read()
    
    client.create_function(
        FunctionName='sqs_send',
        Runtime='python3.13',
        Role=role_arn,
        Handler='sqs_send.lambda_handler',
        Code={
            'ZipFile': sqs_send_code
        },
        Description='Send a message to an SQS queue'
    )

    client.create_function(
        FunctionName='sqs_receive',
        Runtime='python3.13',
        Role=role_arn,
        Handler='sqs_receive.lambda_handler',
        Code={
            'ZipFile': sqs_receive_code
        },
        Description='Receive messages from an SQS queue'
    )

    # Create layers
    with open('requests_layer.zip', 'rb') as f:
        requests_code = f.read()
    
    with open('utility_layer.zip', 'rb') as f:
        utility_code = f.read()

    client.publish_layer_version(
        LayerName='requests',
        Description='Layer containing requests module',
        Content={
            'ZipFile': requests_code
        }
    )
    
    client.publish_layer_version(
        LayerName='utility',
        Description='Layer containing utility module',
        Content={
            'ZipFile': utility_code
        }
    )

